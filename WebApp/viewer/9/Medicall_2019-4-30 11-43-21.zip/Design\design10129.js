angular.module("APP").controller("Design_10129", ['$rootScope', '$scope', '$http', '$q', '$filter',function($rootScope,$scope, $http,$q, $filter){ 

////////////////// code for action : getDocInfoById 

$rootScope.design_10129 = function($scope,param,$event){
	
	url= 'http://172.16.201.42:7001/ehealth-ws-1.2/rest/api/v1/account/doctor/'+$rootScope.DoctorDashboard.id+'';
	$scope.callBack_10129 = function(data){
		$scope.DocInfo = {} ;
		$scope.DocInfo = data;
		//.setDashboard('drDashboard3','drSettingPanel');
		
	
		if($scope.DocInfo.active.id==13){
 			// Navigate : DoctorDashboard/DOCTOR_INFO
 			$scope.navigateULR(180340,190496);
		}

		if($scope.DocInfo.active.id==14){
 			// Navigate : DoctorDashboard/ACTIVE/DEACTIVE
 			$scope.navigateULR(180340,190508);
		}
	}
	$rootScope.sendData($scope,url,null,'Get','callBack_10129');
};



} 
]);