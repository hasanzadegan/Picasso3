angular.module("APP").controller("Design_20215", ['$rootScope', '$scope', '$http', '$q', '$filter',function($rootScope,$scope, $http,$q, $filter){ 

////////////////// code for action : getFindData 

$rootScope.design_20215 = function($scope,param,$event){
	/*$scope.obj = {};
	$scope.obj.input = $scope.searchText;
	$scope.obj.person={};
	$scope.obj.person.gender={};
	$scope.obj.person.gender.id=$scope.gender.id;
	$scope.obj.doctorAccount={};
	$scope.obj.doctorAccount.primaryLanguage={};
	$scope.obj.doctorAccount.primaryLanguage.id=$scope.Form.language;
	$scope.obj.city={};
	$scope.obj.city.id=$scope.Form.city;*/
	url= 'http://172.16.201.42:7001/ehealth-ws-1.2/rest/api/v1/membership/list/find';
	$scope.callBack_20215 = function(data){
		$scope.$eval("findData=" + JSON.stringify(data)) 
		}
	$rootScope.sendData($scope,url,$scope.Form,'Post','callBack_20215');
};



} 
]);