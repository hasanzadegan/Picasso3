angular.module("APP").controller("Design_10159", ['$rootScope', '$scope', '$http', '$q', '$filter',function($rootScope,$scope, $http,$q, $filter){ 

////////////////// code for action : setDashboard 

$rootScope.design_10159 = function($scope,param,$event){
	$rootScope.setDashboard("drDashboard","drProfilePanel");
	};



} 
]);