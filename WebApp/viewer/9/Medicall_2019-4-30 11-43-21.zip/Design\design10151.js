angular.module("APP").controller("Design_10151", ['$rootScope', '$scope', '$http', '$q', '$filter',function($rootScope,$scope, $http,$q, $filter){ 

////////////////// code for action : verifyPatient1 

$rootScope.design_10151 = function($scope,param,$event){
	$scope.nationalCode = localStorage.getItem("__localStorage.__nationalCode");
	
	$rootScope.verifyData={};
	$rootScope.verifyData.person ={};
	$rootScope.verifyData.person.nationalCode = $scope.nationalCode;
	
	url= 'http://172.16.201.42:7001/ehealth-ws-1.2/rest/api/v1/membership/verifypatient';
	$scope.callBack_10151 = function(data){
		localStorage.setItem("__localStorage.__token" , data.jwt_token);
		localStorage.setItem("__localStorage.__CLIENT_ID" , data.client_id);
	
		if(data.mdc_error_code == 1){
 			$rootScope.__toastMessage = $filter('translate')(data.mdc_error_msg);
 			// Design : getPersonInfoById
 			$rootScope.design_10135($scope);
		}

		if(data.mdc_error_code == -1){
 			$rootScope.__toastMessage = $filter('translate')(data.mdc_error_msg);
		}
	}
	$rootScope.sendData($scope,url,$rootScope.verifyData,'Post','callBack_10151');
};



} 
]);