angular.module("APP").controller("Design_10110", ['$rootScope', '$scope', '$http', '$q', '$filter',function($rootScope,$scope, $http,$q, $filter){ 

////////////////// code for action : verifyDoctor 

$rootScope.design_10110 = function($scope,param,$event){
	
	
 		// Navigate : DoctorDashboard/DOCTOR_INFO
	$scope.navigateULR(180340,190496);
};



} 
]);