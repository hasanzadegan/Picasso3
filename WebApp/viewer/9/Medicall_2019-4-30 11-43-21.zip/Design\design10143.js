angular.module("APP").controller("Design_10143", ['$rootScope', '$scope', '$http', '$q', '$filter',function($rootScope,$scope, $http,$q, $filter){ 

////////////////// code for action : goToChangeProgram 

$rootScope.design_10143 = function($scope,param,$event){
	alert($rootScope.workplace.id)
	
 		// Navigate : ChangeProgram/WORK_DAY
	$scope.navigateULR(180365,190540);
};



} 
]);