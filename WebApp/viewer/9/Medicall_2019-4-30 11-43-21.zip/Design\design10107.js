angular.module("APP").controller("Design_10107", ['$rootScope', '$scope', '$http', '$q', '$filter',function($rootScope,$scope, $http,$q, $filter){ 

////////////////// code for action : backToSetPassword 

$rootScope.design_10107 = function($scope,param,$event){
	
	
 		// Navigate : DoctorSignUp/SET_PASSWORD
	$scope.navigateULR(180339,190489);
};



} 
]);