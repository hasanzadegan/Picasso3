angular.module("APP").controller("Design_20209", ['$rootScope', '$scope', '$http', '$q', '$filter',function($rootScope,$scope, $http,$q, $filter){ 

////////////////// code for action : getInitData 

$rootScope.design_20209 = function($scope,param,$event){
	$scope.docId = 	localStorage.getItem("__localStorage.__doctorId"); 
	
};



} 
]);