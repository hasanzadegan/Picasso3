angular.module("APP").controller("Design_20230", ['$rootScope', '$scope', '$http', '$q', '$filter',function($rootScope,$scope, $http,$q, $filter){ 

////////////////// code for action : getDocPass 

$rootScope.design_20230 = function($scope,param,$event){
	
	
 		// Navigate : Sign Up/Password
	$scope.navigateULR(180332,190649);
};



} 
]);