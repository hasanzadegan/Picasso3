angular.module("APP").controller("Design_10104", ['$rootScope', '$scope', '$http', '$q', '$filter',function($rootScope,$scope, $http,$q, $filter){ 

////////////////// code for action : backToGetDoctorId 

$rootScope.design_10104 = function($scope,param,$event){
	
	
 		// Navigate : DoctorSignUp/DOCTOR_COUNCIL_CODE
	$scope.navigateULR(180339,190483);
};



} 
]);