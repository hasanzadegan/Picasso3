angular.module("APP").controller("Design_10101", ['$rootScope', '$scope', '$http', '$q', '$filter',function($rootScope,$scope, $http,$q, $filter){ 

////////////////// code for action : go to Signin 

$rootScope.design_10101 = function($scope,param,$event){
	
	
 		// Navigate : Sign Up/signIn
	$scope.navigateULR(180332,190478);
};



} 
]);