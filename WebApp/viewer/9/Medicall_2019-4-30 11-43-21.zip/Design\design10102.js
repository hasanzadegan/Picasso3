angular.module("APP").controller("Design_10102", ['$rootScope', '$scope', '$http', '$q', '$filter',function($rootScope,$scope, $http,$q, $filter){ 

////////////////// code for action : goToDoctorDashboard 

$rootScope.design_10102 = function($scope,param,$event){
	
	
 		// Navigate : DoctorSignUp/DOCTOR_COUNCIL_CODE
	$scope.navigateULR(180339,190483);
};



} 
]);