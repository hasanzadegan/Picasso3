angular.module("APP").controller("Design_10160", ['$rootScope', '$scope', '$http', '$q', '$filter',function($rootScope,$scope, $http,$q, $filter){ 

////////////////// code for action : backToSpecialty 

$rootScope.design_10160 = function($scope,param,$event){
	
	
 		// Navigate : DoctorSignUp/SPECIALITY
	$scope.navigateULR(180339,190490);
};



} 
]);