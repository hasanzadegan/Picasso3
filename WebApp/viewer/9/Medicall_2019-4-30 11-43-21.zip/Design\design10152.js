angular.module("APP").controller("Design_10152", ['$rootScope', '$scope', '$http', '$q', '$filter',function($rootScope,$scope, $http,$q, $filter){ 

////////////////// code for action : backToWorkplace 

$rootScope.design_10152 = function($scope,param,$event){
	
	
 		// Navigate : DoctorSignUp/WORKPLACE_INFO
	$scope.navigateULR(180339,190495);
};



} 
]);