angular.module("APP").controller("Design_10139", ['$rootScope', '$scope', '$http', '$q', '$filter',function($rootScope,$scope, $http,$q, $filter){ 

////////////////// code for action : goToPatientDashboard 

$rootScope.design_10139 = function($scope,param,$event){
	
	
 		// Navigate : PatientDashboard/PERSONAL_INFO
	$scope.navigateULR(180344,190517);
};



} 
]);