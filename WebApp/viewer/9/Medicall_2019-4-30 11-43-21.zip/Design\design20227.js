angular.module("APP").controller("Design_20227", ['$rootScope', '$scope', '$http', '$q', '$filter',function($rootScope,$scope, $http,$q, $filter){ 

////////////////// code for action : goBackWindow 

$rootScope.design_20227 = function($scope,param,$event){
	window.history.back();
};



} 
]);