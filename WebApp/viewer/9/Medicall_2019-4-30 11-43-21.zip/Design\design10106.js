angular.module("APP").controller("Design_10106", ['$rootScope', '$scope', '$http', '$q', '$filter',function($rootScope,$scope, $http,$q, $filter){ 

////////////////// code for action : backToAccountInfo 

$rootScope.design_10106 = function($scope,param,$event){
	
	
 		// Navigate : DoctorSignUp/ACCOUNT_INFO
	$scope.navigateULR(180339,190488);
};



} 
]);