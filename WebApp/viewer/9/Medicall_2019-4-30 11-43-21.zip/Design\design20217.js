angular.module("APP").controller("Design_20217", ['$rootScope', '$scope', '$http', '$q', '$filter',function($rootScope,$scope, $http,$q, $filter){ 

////////////////// code for action : test1 

$rootScope.design_20217 = function($scope,param,$event){
	$scope.Form = {};
	$scope.Form.Country = '' ; 
};



} 
]);