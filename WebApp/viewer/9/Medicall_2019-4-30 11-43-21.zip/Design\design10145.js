angular.module("APP").controller("Design_10145", ['$rootScope', '$scope', '$http', '$q', '$filter',function($rootScope,$scope, $http,$q, $filter){ 

////////////////// code for action : hasPatientPass 

$rootScope.design_10145 = function($scope,param,$event){
	
	var a = true;
	
		if(a === true){
 			// Design : patientSMS
 			$rootScope.design_20198($scope);
		}
};



} 
]);