angular.module("APP").controller("Design_10137", ['$rootScope', '$scope', '$http', '$q', '$filter',function($rootScope,$scope, $http,$q, $filter){ 

////////////////// code for action : savePersonInfo2dashboard 

$rootScope.design_10137 = function($scope,param,$event){
		$scope.savePersonInfo = {};
		$scope.savePersonInfo.id = $scope.PatientInfo.id;
		$scope.savePersonInfo.firstName = $scope.PatientInfo.firstName;
		$scope.savePersonInfo.lastName =  $scope.PatientInfo.lastName;
		$scope.savePersonInfo.birthDate =  $scope.PatientInfo.birthDate;
		$scope.savePersonInfo.email =  $scope.PatientInfo.email;
		$scope.savePersonInfo.gender = {};
		$scope.savePersonInfo.gender.id =  $scope.PatientInfo.gender.id;
	url= 'http://172.16.201.42:7001/ehealth-ws-1.2/rest/api/v1/account/patient/edit';
	$scope.callBack_10137 = function(data){
	
		if(data.mdc_error_code == 1){
 			$rootScope.__toastMessage = $filter('translate')(data.mdc_error_msg);
		}

		if(data.mdc_error_code == -1){
 			$rootScope.__toastMessage = $filter('translate')(data.mdc_error_msg);
		}
	}
	$rootScope.sendData($scope,url,$scope.savePersonInfo,'Post','callBack_10137');
};



} 
]);