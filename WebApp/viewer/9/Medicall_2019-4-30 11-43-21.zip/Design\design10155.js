angular.module("APP").controller("Design_10155", ['$rootScope', '$scope', '$http', '$q', '$filter',function($rootScope,$scope, $http,$q, $filter){ 

////////////////// code for action : goToSercreteryDashboard 

$rootScope.design_10155 = function($scope,param,$event){
	
	
 		// Navigate : SecreteryDashboard/SECRETERY_INFO
	$scope.navigateULR(180376,190564);
};



} 
]);