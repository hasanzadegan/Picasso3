angular.module("APP").controller("Design_10123", ['$rootScope', '$scope', '$http', '$q', '$filter',function($rootScope,$scope, $http,$q, $filter){ 

////////////////// code for action : showCancelPage 

$rootScope.design_10123 = function($scope,param,$event){
	
	
 		// Navigate : removeDialogues/removeSignUpDoctor
	$scope.navigateULR(180408,190615);
};



} 
]);