angular.module("APP").controller("Design_20222", ['$rootScope', '$scope', '$http', '$q', '$filter',function($rootScope,$scope, $http,$q, $filter){ 

////////////////// code for action : changePhoneNumber 

$rootScope.design_20222 = function($scope,param,$event){
	
	
 		// Navigate : Sign Up/cellPhone
	$scope.navigateULR(180332,190476);
};



} 
]);