angular.module("APP").controller("Design_20231", ['$rootScope', '$scope', '$http', '$q', '$filter',function($rootScope,$scope, $http,$q, $filter){ 

////////////////// code for action : getSecPass 

$rootScope.design_20231 = function($scope,param,$event){
	
	
 		// Navigate : Sign Up/Password
	$scope.navigateULR(180332,190648);
};



} 
]);