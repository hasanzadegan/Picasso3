angular.module("APP").controller("Design_10142", ['$rootScope', '$scope', '$http', '$q', '$filter',function($rootScope,$scope, $http,$q, $filter){ 

////////////////// code for action : goToWeeklyProgram 

$rootScope.design_10142 = function($scope,param,$event){
	
	
 		// Navigate : WeeklyProgram/weeklyProgram
	$scope.navigateULR(180364,190544);
};



} 
]);