angular.module("APP").controller("Design_10158", ['$rootScope', '$scope', '$http', '$q', '$filter',function($rootScope,$scope, $http,$q, $filter){ 

////////////////// code for action : getSecInfoById 

$rootScope.design_10158 = function($scope,param,$event){
	
};



} 
]);