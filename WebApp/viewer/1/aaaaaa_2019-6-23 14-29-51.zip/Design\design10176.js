angular.module("APP").controller("Design_10176", ['$rootScope', '$scope', '$http', '$q', '$filter',function($rootScope,$scope, $http,$q, $filter){ 

////////////////// code for action : key 

$rootScope.design_10176 = function($scope,param,$event){
	$scope.key=1;
	alert($scope.key);
	$event.preventDefault(); 
};



} 
]);