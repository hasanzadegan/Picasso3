var app = angular.module('YourApp', ['ngMaterial', 'ngMessages', 'ngMdIcons', 'ngRoute', 'ngAnimate', 'ngCookies', 'lfNgMdFileInput', 'oc.lazyLoad']);
app.controller('HamfekranController', function($scope, $rootScope) {

});