angular.module('APP').controller('accountCtrl', function($scope, $rootScope) {

});