angular.module('YourApp').controller('contentCtrl', function($scope,$rootScope) {
});