angular.module('YourApp').controller('myProfileCtrl', function($scope, $rootScope) {
	$scope.optoin08 = {
                    "browseIconCls":"myBrowse",
                    "removeIconCls":"myRemove",
                    "captionIconCls":"myCaption",
					"submitIconCls":"mySubmit",
					"unknowIconCls":"myUnknow"
    };
});