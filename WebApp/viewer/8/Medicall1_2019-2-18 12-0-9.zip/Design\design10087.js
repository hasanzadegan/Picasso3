angular.module("APP").controller("Design_10087", ['$rootScope', '$scope', '$http', '$q', '$filter',function($rootScope,$scope, $http,$q, $filter){ 

////////////////// code for action : go to aa 

$rootScope.design_10087 = function($scope){
	
	
 		// Navigate : new Page/aa
	$scope.navigateULR(180330,190460);
};



} 
]);