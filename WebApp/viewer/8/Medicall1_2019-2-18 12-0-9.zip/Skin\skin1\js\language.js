angular.module('APP').controller('langCtrl', function($scope, $rootScope) {

});