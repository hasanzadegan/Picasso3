angular.module("APP").controller("Design_10116", ['$rootScope', '$scope', '$http', '$q', '$filter',function($rootScope,$scope, $http,$q, $filter){ 

////////////////// code for action : cc 

$rootScope.design_10116 = function($scope){

 		// Navigate : new Page/aa
	$scope.$parent.navigateULR(180330,190460);
};



} 
]);