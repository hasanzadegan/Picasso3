angular.module("APP").controller("Design_10115", ['$rootScope', '$scope', '$http', '$q', '$filter',function($rootScope,$scope, $http,$q, $filter){ 

////////////////// code for action : cc 

$rootScope.design_10115 = function($scope){
	//$scope.$parent.$parent.$parent.pageId = '180330';
	$scope.navigateULR('180330','190514');
 		// Navigate : new Page/bb
};



} 
]);