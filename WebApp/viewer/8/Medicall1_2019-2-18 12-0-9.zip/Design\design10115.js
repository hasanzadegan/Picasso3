angular.module("APP").controller("Design_10115", ['$rootScope', '$scope', '$http', '$q', '$filter',function($rootScope,$scope, $http,$q, $filter){ 

////////////////// code for action : cc 

$rootScope.design_10115 = function($scope){
	console.log("salam")
	
 		// Navigate : new Page/bb
	$scope.navigateULR(180330,190514);
};



} 
]);