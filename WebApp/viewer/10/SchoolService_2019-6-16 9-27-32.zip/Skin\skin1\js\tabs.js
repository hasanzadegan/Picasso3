angular.module('YourApp').controller('tabsCtrl', function($scope,$rootScope) {

});