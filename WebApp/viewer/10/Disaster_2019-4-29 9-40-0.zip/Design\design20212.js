angular.module("APP").controller("Design_20212", ['$rootScope', '$scope', '$http', '$q', '$filter',function($rootScope,$scope, $http,$q, $filter){ 

////////////////// code for action : SignOut 

$rootScope.design_20212 = function($scope,param,$event){
	
	
 		// Navigate : Disaster/Authorize
	$scope.navigateULR(180409,190616);
};



} 
]);