angular.module("APP").controller("Design_20213", ['$rootScope', '$scope', '$http', '$q', '$filter',function($rootScope,$scope, $http,$q, $filter){ 

////////////////// code for action : NewMission 

$rootScope.design_20213 = function($scope,param,$event){
	
	
 		// Navigate : Disaster/RegisterMission
	$scope.navigateULR(180409,190619);
};



} 
]);